rms
=====

Regression Modeling Strategies

Current Goals
=============


Web Sites
=============
* Overall: http://biostat.mc.vanderbilt.edu/Rrms
* Book: http://biostat.mc.vanderbilt.edu/rms
* CRAN: http://cran.r-project.org/web/packages/rms
* Changelog: https://github.com/harrelfe/rms/commits/master

To Do
=====
Fix survplot so that explicitly named adjust-to values are still in subtitles.  See tests/cph2.s.
